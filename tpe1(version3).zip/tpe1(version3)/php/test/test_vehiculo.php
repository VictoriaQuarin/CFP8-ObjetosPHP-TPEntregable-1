<?php ini_set("display_errors","1"); ?>
<?php

    require_once "../entities/vehiculo.php";
    require_once "../entities/radio.php";
    require_once "../entities/auto_clasico.php";
    require_once "../entities/auto_nuevo.php";
    require_once "../entities/colectivo.php";

    //http://localhost/objetos/tpe1(version3)/php/test/test_vehiculo.php


    echo "<h1>Test TP Entregable 1 - Vehículos </h1><br>";

    echo "<h2>-- Test Radio --</h2>";
    echo "-- Radio 1 --<br>";
    $radio1=new Radio('Sony', '125');
    echo $radio1."<br><br><br>";

    

    echo "<h2>-- Test Auto Clásico--</h2>";
    echo "-- Auto Clásico 1 --<br>";
    $autoClasico1=new AutoClasico("Negro", "Ford", "Mustang", 45000);
    echo $autoClasico1."<br>";
    echo $autoClasico1->agregarRadio("Philips", 130);
    echo $autoClasico1."<br><br><br>";



    echo "<h2>-- Test Auto Nuevo--</h2>";
    echo "-- Auto Nuevo 1--<br>";
    $autoNuevo1=new AutoNuevo("Rojo","Chevrolet","Corsa", 90000, "Panasonic");
    echo $autoNuevo1."<br>";
    echo $autoNuevo1->cambiarRadio("Philips", 300);
    echo $autoNuevo1."<br><br><br>";


    /*
    
    CONSTRUCTOR DE AUTO NUEVO CON MODIFICACIÓN

    public function __construct(string $color, string $marca, string $modelo, float $precio, string $marca_radio, int $potencia){
        $this->color = $color;
        $this->marca = $marca;
        $this->modelo = $modelo;
        $this->precio = $precio;
        $this->marca_radio = $marca_radio;
        $this->potencia = $potencia;
    }



    TEST DE AUTO NUEVO CON MODIFICACIÓN

    echo "<h2>-- Test Auto Nuevo--</h2>";
    echo "-- Auto Nuevo 1--<br>";
    $autoNuevo1=new AutoNuevo("Rojo","Chevrolet","Corsa", 90000, "Panasonic", 100);
    echo $autoNuevo1."<br>";
    echo $autoNuevo1->cambiarRadio("Philips", 300);
    echo $autoNuevo1."<br><br><br>";

    */


    echo "<h2>-- Test Colectivo--</h2>";
    echo "-- Colectivo 1 --<br>";
    $colectivo1=new Colectivo("Azul", "Mercedes Benz", "Sprinter", 150000);
    echo $colectivo1."<br>";
    echo $colectivo1->agregarRadio("Sony", 300);
    echo $colectivo1."<br><br><br>";



    echo "-- End Test Vehículos --<br><br>";


?>
