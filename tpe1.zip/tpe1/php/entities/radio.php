<?php
require_once "../entities/radio.php";

class Radio{

    public $marca;

    public $potencia;

}
?>