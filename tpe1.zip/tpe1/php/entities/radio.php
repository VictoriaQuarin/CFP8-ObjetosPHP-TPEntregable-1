<?php
require_once "../entities/radio.php";

class Radio{

    public $marca_radio;

    public $potencia;



    public function __construct(string $marca_radio, int $potencia){
        $this->marca_radio = $marca_radio;
        $this->potencia = $potencia;
    }

    public function __tostring() :string{
        return $this->marca_radio.", ".$this->potencia;
    }


}
?>