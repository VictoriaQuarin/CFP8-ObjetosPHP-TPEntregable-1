<?php
require_once "../entities/vehiculo.php";

abstract class Vehiculo{

    public $color;

    public $marca;

    public $modelo;

    public $precio;

    public $radio;


    public function agregarRadio(string $marca_radio, int $potencia){
        $this->radio = new Radio($marca_radio, $potencia);
    }
    
    public function cambiarRadio(string $marca_radio, int $potencia){
        $this->radio = new Radio($marca_radio, $potencia);
    }


    public function __tostring() :string{
        return $this->color.", " .$this->marca. ", ".$this->modelo.", ".$this->precio. ", ".$this->radio;
    }


}
?>