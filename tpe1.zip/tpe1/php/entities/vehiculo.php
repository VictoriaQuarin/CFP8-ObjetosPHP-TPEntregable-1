<?php
require_once "../entities/vehiculo.php";

abstract class Vehiculo{

    public $color;

    public $marca;

    public $modelo;

    public $radio;

    public $precio;

    /*public $potencia;*/




    public function agregarRadio(string $marca, int $potencia){
        return "Una radio de marca $this->marca y de potencia de $this->potencia watts fue agregada.<br>";
    }
    
    public function cambiarRadio(string $marca, int $potencia){
        return "Una radio de marca $this->marca y de potencia de $this->potencia watts fue cambiada.<br>";
    }

}
?>