<?php
require_once "../entities/vehiculo.php";
require_once "../entities/radio.php";

class AutoNuevo extends Vehiculo{


    public function __construct(string $color, string $marca, string $modelo, string $radio, float $precio){
        $this->color = $color;
        $this->marca = $marca;
        $this->modelo = $modelo;
        $this->radio = $radio;
        $this->precio = $precio;
    }


}
?>