<?php ini_set("display_errors","1"); ?>
<?php

    require_once "../entities/vehiculo.php";
    require_once "../entities/radio.php";
    require_once "../entities/auto_clasico.php";
    require_once "../entities/auto_nuevo.php";
    require_once "../entities/colectivo.php";

    //http://localhost/objetos/tpe1/php/test/test_vehiculo.php


    echo "<h1>Test TP Entregable 1 - Vehículos </h1><br>";

    echo "<h2>-- Test Radio --</h2>";
    echo "-- Radio 1 --<br>";
    $radio1=new Radio('Sony', '125');
    echo $radio1."<br><br><br>";
    // Al querer ejecutar las dos líneas siguientes; se genera un error en la salida. 
    // Fatal error: Uncaught Error: Call to undefined method Radio::cambiarRadio() in C:\xampp\htdocs\objetos\tpe1\php\test\test_vehiculo.php
    // echo $radio1->cambiarRadio("Panasonic", 300);
    // echo $radio1."<br><br><br><br>";

    

    echo "<h2>-- Test Auto Clásico--</h2>";
    echo "-- Auto Clásico 1 --<br>";
    $autoClasico1=new AutoClasico("Negro", "Ford", "Mustang", 45000);
    echo $autoClasico1."<br>";
    echo $autoClasico1->agregarRadio("Philips", 130);
    echo $autoClasico1."<br><br><br>";



    // La salida de AUTO NUEVO no genera error al ejecutarse, sin embargo no efectiviza el cambio de la radio, por una distinta (como debería de hacerlo). 
    // -- Salida --
    // -- Auto Nuevo 1 --
    // Rojo, Corsa, Sony, 90000, 250 (ejecución de línea 43)
    // Rojo, Corsa, Sony, 90000, 250 (ejecución de línea 45)
    // ¿Sería necesaria la creación de "Radio2", para diferenciar la radio utilizada en agregarRadio; y la radio que se utiliza en cambiarRadio?
    echo "<h2>-- Test Auto Nuevo--</h2>";
    echo "-- Auto Nuevo 1--<br>";
    $autoNuevo1=new AutoNuevo("Rojo","Corsa","Sony", 250, 90000);
    echo $autoNuevo1."<br>";
    echo $autoClasico1->cambiarRadio("Philips", 300);
    echo $autoNuevo1."<br><br><br>";



    echo "<h2>-- Test Colectivo--</h2>";
    echo "-- Colectivo 1 --<br>";
    $colectivo1=new Colectivo("Azul", "Mercedes Benz", "Sprinter", 150000);
    echo $colectivo1."<br>";
    echo $colectivo1->agregarRadio("Sony", 300);
    echo $colectivo1."<br><br><br>";



    echo "-- End Test Vehículos --<br><br>";


?>
