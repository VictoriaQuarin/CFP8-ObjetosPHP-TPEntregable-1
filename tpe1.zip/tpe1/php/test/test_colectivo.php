<?php ini_set("display_errors","1"); ?>
<?php

    require_once "../entities/vehiculo.php";
    require_once "../entities/radio.php";
    require_once "../entities/auto_clasico.php";

    //http://localhost/objetos/tpe1/php/test/test_auto_clasico.php


    echo "<h1>Test TP Entregable 1 - Vehículos </h1><br>";
    echo "<h2>-- Test Colectivo --</h2><br>";
    echo "-- Auto Colectivo --<br>";

    echo "-- End Test Colectivo --<br><br>";

?>