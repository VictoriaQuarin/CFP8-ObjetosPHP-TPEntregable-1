<?php ini_set("display_errors","1"); ?>
<?php

    require_once "../entities/vehiculo.php";
    require_once "../entities/radio.php";
    require_once "../entities/auto_clasico.php";

    //http://localhost/objetos/tpe1/php/test/test_auto_clasico.php


    echo "<h1>Test TP Entregable 1 - Vehículos </h1><br>";
    echo "<h2>-- Test Auto Nuevo --</h2><br>";
    echo "-- Auto Nuevo 1 --<br>";

    echo "-- End Test Auto Nuevo--<br><br>";

?>